var base_url = "http://10.127.247.172";
var url_mahasiswa = "http://10.127.247.172:9004/api/v1";
var url_matakuliah = "http://10.127.247.172:9005/api/v1";
var url_nilai = "http://10.127.247.172:9006/api/v1";
