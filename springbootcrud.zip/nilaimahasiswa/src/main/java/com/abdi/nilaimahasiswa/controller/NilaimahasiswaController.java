/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.abdi.nilaimahasiswa.controller;

import java.util.List;
import com.abdi.nilaimahasiswa.entity.Nilaimahasiswa;
import com.abdi.nilaimahasiswa.service.NilaimahasiswaService;
import com.abdi.nilaimahasiswa.vo.ResponseTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author abdil
 */

@RestController
@RequestMapping("api/v1/nilai")
public class NilaimahasiswaController {
    @Autowired
    private NilaimahasiswaService nilaiService;
    
    @GetMapping
    public List<Nilaimahasiswa> getAll(){
        return nilaiService.getAll();
    }
    
    @PostMapping
    public void insert(@RequestBody Nilaimahasiswa nilai){
        nilaiService.insert(nilai);
    }
    
     @GetMapping(path = "{id}")
    public List <ResponseTemplate> getNilai(@PathVariable("id") Long id){
        return nilaiService.getNilaiById(id);
    }
}
