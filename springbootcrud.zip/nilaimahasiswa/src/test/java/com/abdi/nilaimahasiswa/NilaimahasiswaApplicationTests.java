package com.abdi.nilaimahasiswa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NilaimahasiswaApplicationTests {

	@Test
	void contextLoads() {
	}

}
